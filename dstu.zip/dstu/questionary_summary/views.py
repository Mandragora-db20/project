from django.shortcuts import render

import matplotlib.pyplot as plt
import numpy as np

from .models import Questionary
# Create your views here.


def home(request, discipline_id, learning_start_year, plan_id):
    labels = ['Кругозор', 'Карьера', 'Новизна', 'Сложность']

    # TODO: запросы на основе Django ORM через модель Questionary для получения статистических данных.
    #  Накапливаем в 4 списках:

    # Заглушки со стат. данными по каждой категории в списках:
    stud_summary_set = [14, 28, 30, 35]
    top100_summary_set = [25, 32, 24, 25]
    graduate_summary_set = [21, 36, 30, 27]
    specialist_summary_set = [23, 30, 28, 20]

    # Построение изображения с диаграммой
    x = np.arange(len(labels))  # the label locations
    width = 0.15  # the width of the bars

    fig, ax = plt.subplots()
    rects1 = ax.bar(x - 2 * width, stud_summary_set, width, label='Студенты')
    rects2 = ax.bar(x - width, top100_summary_set, width, label='Топ-100')
    rects3 = ax.bar(x, graduate_summary_set, width, label='Трудоустроенные выпускники')
    rects4 = ax.bar(x + width, specialist_summary_set, width, label='Трудоустроенные вып-ки по специальности')

    # Add some text for labels, title and custom x-axis tick labels, etc.
    ax.set_ylabel('Процент проголосовавших по категории')
    ax.set_title('Оценка полезности дисциплины: Численные методы')
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.legend()

    def autolabel(rects):
        """Attach a text label above each bar in *rects*, displaying its height."""
        for rect in rects:
            height = rect.get_height()
            ax.annotate('{}'.format(height),
                        xy=(rect.get_x() + rect.get_width() / 2, height),
                        xytext=(0, 3),  # 3 points vertical offset
                        textcoords="offset points",
                        ha='center', va='bottom')

    autolabel(rects1)
    autolabel(rects2)
    autolabel(rects3)
    autolabel(rects4)

    fig.tight_layout()
    plt.show()

    # TODO: генерация файла с изображением диаграммы. имя -> в img_file_name

    img_file_name = './summary.png'  # заглушка под будущую параметризацию имени
    fig.savefig(img_file_name, format='png')

    return render(request, 'home.html', **{'data': img_file_name})