from django.db import models

# Create your models here.


class Questionary(models.Model):
    plan_id = models.IntegerField(default=0)
    learning_start_year = models.IntegerField(default=1900)
    discipline_id = models.IntegerField(default=0)
    surname = models.CharField(max_length=50)
    name = models.CharField(max_length=50)
    father_name = models.CharField(max_length=50)
    category = models.CharField(max_length=20)
    purview_answer = models.BooleanField(default=False)  # кругозор
    career_answer = models.BooleanField(default=False)  # карьера
    recency_answer = models.BooleanField(default=False)  # новизна
    complexity_answer = models.BooleanField(default=False)  # сложность
