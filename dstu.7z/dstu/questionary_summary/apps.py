from django.apps import AppConfig


class QuestionarySummaryConfig(AppConfig):
    name = 'questionary_summary'
